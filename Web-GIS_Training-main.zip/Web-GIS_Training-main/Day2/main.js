// var num = 26;
// var num2 = 20;

// // If statement
// // if(num > num2){
// //     console.log("num is greater than num2");
// // }

// // for(var x=0; x<10; x++){
// //     console.log(x);
// // }

// // function
// function add(a , b){
//     console.log(a + b);
// }

// // add(num, 5);

// var myArray = [1, 2, 3, "hello", true];
// console.log(myArray[2]);

// // My object
// var myObject = {
//     name: "aditya",
//     age: 26
// }

// console.log(myObject);


var x = document.getElementById("gesan").innerHTML;
console.log(x);

function buttonClick(){
    x.style.color = 'red';
}